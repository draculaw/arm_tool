/*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====
    Copyright (c) 2018 Neoway Technologies, Inc.
    All rights reserved.
    Confidential and Proprietary - Neoway Technologies, Inc.
    Author: Shi.Shaogang
    Date: 2018.06
*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*/

#include "nwy_adc.h"
#include "nwy_common.h"

/*---------------------------Macro Definition---------------------------*/
#undef LOG_FORMAT
#define LOG_FORMAT       LOG_SIMPLE
#undef LOG_MSG_TAG
#define LOG_MSG_TAG      "ADC"
#undef LOG_MSG_LEVEL
#define LOG_MSG_LEVEL    LOG_DEBUG
#undef LOG_MSG_MASK
#define LOG_MSG_MASK     LOG_MASK_STD

/*---------------------------Function Definition--------------------------*/
static inline char *input_fgets(char *msg, ...)
{
	static char ptr[128] = { 0 };
	va_list ap;

	va_start(ap, msg);
	vprintf(msg, ap);
	va_end(ap);
	memset(ptr, 0, sizeof(ptr));
	fgets(ptr, sizeof(ptr), stdin);
	if(strlen(ptr) > 0) {
		if('\n' == ptr[strlen(ptr) - 1]) {
			ptr[strlen(ptr) - 1] = '\0';
		}
	}
	return ptr;
}

int main(int argc, char *argv[])
{
	int adc_val;
	char *sptr = NULL;

	LOGI("Adc Sample");

	while (1) {
		sptr = input_fgets("\nPlease select ADC channel NO. (1-ADC1, 2-ADC2, 3-ADC3, q-Exit): ");
		if (sptr[0] == 'q')
			return 0;
		switch (atoi(sptr)) {
			case 1:
				adc_val = nwy_adc_get(NWY_ADC1);
				LOGI("Adc1 val = %duv", adc_val);
				break;
			case 2:
				adc_val = nwy_adc_get(NWY_ADC2);
				LOGI("Adc2 val = %duv", adc_val);
				break;
			case 3:
				adc_val = nwy_adc_get(NWY_ADC3);
				LOGI("Adc3 val = %duv", adc_val);
				break;
			default:
				break;
		}
	}

	return 0;
}
