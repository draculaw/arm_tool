/*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====
    Copyright (c) 2018 Neoway Technologies, Inc.
    All rights reserved.
    Confidential and Proprietary - Neoway Technologies, Inc.
    Author: wangxiaobo
    Date: 2018/7
*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <regex.h>

#include "nwy_error.h"
#include "nwy_sms.h"
#include "nwy_common.h"

/*---------------------------Macro definition---------------------------*/
#undef LOG_MSG_TAG
#define LOG_MSG_TAG     "SMS_TEST"

#undef LOG_MSG_LEVEL
#define LOG_MSG_LEVEL    LOG_DEBUG

#undef LOG_MSG_MASK
#define LOG_MSG_MASK     LOG_MASK_STD

#define OVECCOUNT 30
#define EBUFLEN 128
#define BUFLEN 1024

#if 1
#define PRINTF(fmt,...)  do \
                   { \
				   		fprintf(stderr, fmt, ##__VA_ARGS__); \
                   }while(0)
#else
#define PRINTF(fmt,...)  do \
                   { \
				   		printf(fmt, ##__VA_ARGS__); \
                   }while(0)

#endif


/*---------------------------Variable Definition--------------------------*/

char *help_str = "please choice the action or waiting for incomming message\n" \
                  " 1) for send, \n" \
                  " 2) for delete, \n" \
                  " 3) for route, \n" \
                  " 4) for get sca, \n" \
                  " 5) for set sca, \n" \
                  " 6) for get sms storage list, \n" \
                  " 7) for get storage message context, \n" \
                  " 8) for send async, \n" \
                  " 9) for send repeat, \n" \
                  " 0) for exit\n> ";

/*---------------------------Function Definition--------------------------*/

static inline char *input_fgets(char *msg, ...)
{
    static char ptr[10*1024] = { 0 };
    va_list ap;
    memset(ptr, 0, 10*1024);

    va_start(ap, msg);
    vprintf(msg, ap);
    va_end(ap);
    memset(ptr, 0, sizeof(ptr));
    fgets(ptr, sizeof(ptr), stdin);
    if(strlen(ptr) > 0) {
        if('\n' == ptr[strlen(ptr) - 1]) {
            ptr[strlen(ptr) - 1] = '\0';
        }
    }
    return ptr;
}

int is_all_dig(char *buf)
{
    regex_t reg;
    char errbuf[1024];
    char *pattern = "^[0-9]*$";
    int err,nm = 10;
    int result = 0;
    regmatch_t pmatch[nm];

    if(regcomp(&reg,pattern,REG_EXTENDED) < 0){
        //regerror(err,&reg,errbuf,sizeof(errbuf));
        return 0;
    }
        err = regexec(&reg,buf,nm,pmatch,0);

    if(err == REG_NOMATCH){
        return 0;

    }else if(err){
        return 0;
    }
    return 1;

}


int sms_test_set_routes(nwy_sms_storage_type_t storage, nwy_sms_receipt_action_type_t action)
{
    int result = 0;

    nwy_sms_route_t routes = { 0 };
    int i = 0;

    for (i = 0; i < NWY_SMS_MESSAGE_CLASS_LEN; i++) {
        routes.route_list[i].storage = storage;
        routes.route_list[i].action = action;
    }

    result = nwy_sms_set_routes(&routes);

    return result;
}

int sms_test_send_msg(char *phone, char *text)
{
    int result = 0;
    int i = 0;
    nwy_sms_info_type_t sms_data = { 0 };

    sms_data.msg_context_len = strlen(text);
    strcpy(sms_data.msg_context, text);
    sms_data.msg_format = NWY_SMS_MSG_FORMAT_TEXT_ASCII;
    strcpy(sms_data.phone_num, phone);

    result = nwy_sms_send_message(&sms_data);
    return result;
}

static void test_sms_evt_handler(nwy_mt_sms_event_t ind_type, void *ind_struct)
{
    static int c = 0;

    PRINTF("Nwy_mt_sms_event %x\n", ind_type);
    switch (ind_type) {
        case NWY_SMS_PP_IND:
            {
                nwy_sms_pp_info_type_t *sms_pp;
                sms_pp = ind_struct;
            PRINTF("recv msg from %s\n", sms_pp->source_phone_num);
            PRINTF("recv msg type %d\n", sms_pp->msg_format);
                if (sms_pp->concat_sms_total > 0) {
                PRINTF("this is the part %d of long message has %d message entry\n", 
                        sms_pp->concat_sms_cur, sms_pp->concat_sms_total);
                PRINTF("concat msg id %d\n", sms_pp->concat_sms_id);
                }
                if (sms_pp->msg_format == NWY_SMS_MSG_FORMAT_TEXT_ASCII)
                PRINTF("recv msg text %s\n", sms_pp->msg_content);
                else {
                    int i = 0;
                PRINTF("recv msg data:\n", sms_pp->msg_content);
                    for (i = 0; i < sms_pp->msg_content_len; i++) {
                    PRINTF("%02x", sms_pp->msg_content[i]);
                    }
                PRINTF("\n");;
                }

                if (sms_pp->context_decode_type == NWY_SMS_ENCODING_GBK) {

                PRINTF("gbk data is :\n%s\n", sms_pp->msg_decoded_content);
                }

                c ++;
            }
            break;
        case NWY_SMS_SEND_IND:
            {
                nwy_sms_send_ind_t *send_result = ind_struct;
                if (send_result->result == 0) {
                    PRINTF("we send msg to %s result ok\n", send_result->phone_num);
                } else {
                    PRINTF("we send msg to %s result failed\n", send_result->phone_num);
                }
            }
            break;
        default:
            PRINTF("we do not support this event now %x\n", ind_type);
    }
    PRINTF("have recv %d sms entry\n");
    PRINTF("--------------------------------------\n");
    PRINTF(help_str);
    fflush(stdout);
}

int test_set_sms_route()
{
    int result = 0;
    //char storage[80], action[80];
    char *storage, *action;
    int st, ac;

    storage = input_fgets("please select the storage, n for no storage, s for sim\n");

    switch (storage[0]) {
        case 'n':
            st = NWY_SMS_STORAGE_TYPE_NV_V01;
            break;
        case 's':
            st = NWY_SMS_STORAGE_TYPE_UIM_V01;
            break;
        default:
            PRINTF("inncorrect input\n");
            fflush(stdout);
            return -1;
    }

    action = input_fgets("\nplease select the action, s for recv, d for discard\n");

    switch (action[0]) {
        case 's':
            switch (st)
            {
                case NWY_SMS_STORAGE_TYPE_UIM_V01:
                    ac = NWY_SMS_STORE_AND_NOTIFY_V01;
                    break;
                default:
                    ac = NWY_SMS_TRANSFER_AND_ACK_V01;
                    break;
            }
            break;

        case 'd':
            ac = NWY_SMS_DISCARD_V01;
            break;
        default:
            PRINTF("inncorrect input\n");
            fflush(stdout);
            return -1;
    } 

    PRINTF("you select is %d %d\n", st, ac);
    fflush(stdout);

    result = sms_test_set_routes(st, ac);

    return 0;
}

int test_delete_sms()
{
    int result = 0;
    char *storage, *index, *mode;
    int st, i, m;

    mode = input_fgets("please select the network c for cdma, w for others\n");
    switch (mode[0]) {
        case 'c':
            m = NWY_SMS_MODE_CDMA;
            break;
        default:
            m = NWY_SMS_MODE_GW;
            break;
    }

    storage = input_fgets("please select the storage, n for nv s for sim\n");

    switch (storage[0]) {
        case 'n':
            st = NWY_SMS_STORAGE_TYPE_NV_V01;
            break;
        case 's':
            st = NWY_SMS_STORAGE_TYPE_UIM_V01;
            break;
        default:
            PRINTF("inncorrect input\n");
            fflush(stdout);
            return -1;
    }

    index = input_fgets("\nplease input the index \n");
    i = atoi(index);

    if (is_all_dig(index) != 1) {
        PRINTF("input incorrect\n");
        return -1;
    }

    result = nwy_sms_delete_message(st, i, m);
    if (result != 0) {
        if (result == NWY_SMS_E_INVALID_INDEX) {
            PRINTF("invaild index\n");
        } else if (result = NWY_SMS_E_NO_ENTRY) {
            PRINTF("empty entry\n");
        }
        else {
            PRINTF("Unknown Error\n");
        }

    } else {
        PRINTF("deleted\n");
    }
    fflush(stdout);

    return result;
}

static int do_send_sms(
        char *number, int encoding, int length, char *context, int async)
{
    int result = 0;
    /*
       char phone_num[NWY_SMS_MAX_ADDR_LENGTH];
       uint32_t msg_context_len;
       char msg_context[NWY_SMS_MAX_MO_MSG_LENGTH + 1];
       nwy_sms_msg_format_type_t msg_format;
       */

    nwy_sms_info_type_t sms_data = {0};

    strcpy(sms_data.phone_num, number);
    sms_data.msg_context_len = length;

	

    if (encoding == 1) {
        sms_data.msg_format = NWY_SMS_MSG_FORMAT_TEXT_UTF8;
    }
    else if (encoding == 2) {
        sms_data.msg_format = NWY_SMS_MSG_FORMAT_TEXT_GBK;
        length = strlen(context);
    }
    else if (encoding == 0)
        sms_data.msg_format = NWY_SMS_MSG_FORMAT_TEXT_ASCII;
    else if (encoding == 3)
        sms_data.msg_format = NWY_SMS_MSG_FORMAT_BIN;


    memcpy(sms_data.msg_context, context, length + 1);

    //int nwy_sms_send_message ( nwy_sms_info_type_t *p_sms_data );
    if (async == 1) {

        char *h = input_fgets("please set the max waiting time (by second)\n");
        int r = atoi(h);

        if (is_all_dig(h) != 1) {
            PRINTF("input incorrect\n");
            return -1;
        }

        result = nwy_sms_send_message_async(&sms_data, r);
    }
    else if (async == 2) {

        char *h = input_fgets("please set the repeat time\n");
        int r = atoi(h);
        int c = 0;
        int i = 0;

        if (is_all_dig(h) != 1) {
            PRINTF("input incorrect\n");
            return -1;
        }

        for (i = 0; i < r; i++) {
            result = nwy_sms_send_message(&sms_data);
            if (result != 0) {
                c++;
				PRINTF("this time result is %d\n", result);
				PRINTF("send %d time failed %d \n", i, c);
            }
			else{
				//PRINTF("this time result is %d\n", result);
				PRINTF("send %d time success\n", i);
			}
			sleep(1);
        }
    }
    else {
        result = nwy_sms_send_message(&sms_data);
    }

    return result;
}

static char char_to_hex(char c)
{
    char r = 0;

    if (c <= '9' && c >= '0') {
        r = c - '0';
    } else if (c <= 'F' && c >= 'A') {
        r = c - 'A' + 10;
    } else if (c <= 'f' && c >= 'a') {
        r = c - 'a' + 10;
    }
    return r;
}

static char chars_to_hex(char h, char l)
{
    char result = 0;

    result = (char_to_hex(h) << 4) + char_to_hex(l);

    return result;
}

int is_phone_number(char *phone_num)
{
    regex_t reg;
    char errbuf[1024];
    char *pattern = "^\\+?[0-9]{3,20}$";
    int err,nm = 10;
    int result = 0;
    regmatch_t pmatch[nm];

    if(regcomp(&reg,pattern,REG_EXTENDED) < 0){
        //regerror(err,&reg,errbuf,sizeof(errbuf));
        return 0;
    }
        err = regexec(&reg,phone_num,nm,pmatch,0);

    if(err == REG_NOMATCH){
        return 0;

    }else if(err){
        return 0;
    }
    return 1;
}


int test_send_sms(int async)
{
    int result = 0;
    char number[80];
    int encoding, length;
    char *number_ptr, *encoding_ptr, *length_ptr;
    int len = 0;
    char *context = NULL;
    char *context_ptr = NULL;


    number_ptr = input_fgets("please input the dest number\n");
    strncpy(number, number_ptr, 20);
    if (is_phone_number(number) != 1) {
        PRINTF("error %s not an phone_num\n", number);
        return -1;
    }
    //scanf("%s", number);

    encoding_ptr = input_fgets("please input the encoding 0 for GSM7-default 1 for UCS2 2 for GBK\n");

    switch (encoding_ptr[0]) {
        case '0':
            encoding = 0;
            break;
        case '1':
            encoding = 1;
            break;
        case '2':
            encoding = 2;
            break;
        case '3':
            encoding = 3;
            break;
        default:
            PRINTF("inncorrect input\n");
            fflush(stdout);
            return -1;
    }

    length_ptr = input_fgets("please input the msg len, max len 600 for gsm7 and 300 for UCS2 and GBK\n");
    //scanf("%s", length);
    len = atoi(length_ptr);
    if (is_all_dig(length_ptr) != 1) {
    	PRINTF("input incorrect\n");
        return -1;
    }

	if(encoding == 0)
	{
		if(len > 600)
		{
			PRINTF("input incorrect! max len 600\n");
			return -1;
		}
	}
	else if((encoding == 1) || (encoding == 2))
	{
		if(len > 300)
		{
			PRINTF("input incorrect! max len 300\n");
			return -1;
		}
	}


    if (encoding == 1) {
        len = 4 * len;
    }

    context = malloc(10*1000);
    if (context == NULL) {
        PRINTF("out of memory\n");
        fflush(stdout);
        exit(EXIT_FAILURE);
    }
    memset(context, 0, 5*1000);

    context_ptr= input_fgets("please input the msg context,\n"
            " if is GSM7 input it is text mode\n"
            " if the UCS2 should input UCS2 code like \'4f60\'\n");
    memcpy(context, context_ptr, 10*1000); 
//    scanf("%s", context);

    if (encoding == 1 || encoding == 3) {
        int i = 0;

        int hex_len = (len  / 2);

        if (encoding == 3) {
            hex_len = len;
        }
        
        char *hex_context = NULL;

        hex_context = malloc(5 * 1000);
        if (hex_context == NULL) {
            PRINTF("out of memory\n");
            fflush(stdout);
            exit(EXIT_FAILURE);
        }
        memset(hex_context, 0, 5*1000);

        for (i = 0; i < hex_len; i++) {
            hex_context[i] = chars_to_hex(context[2 * i], context[2 * i + 1]);
        }

        result = do_send_sms(number, encoding, hex_len, hex_context, async);

        free(hex_context);
        hex_context = NULL;
    } else if (encoding == 3) {
    } else {
        result = do_send_sms(number, encoding, len, context, async);
    }

    free(context);
    context = NULL;

    return result;
}

void test_qmi_send_ascii()
{
    uint8_t encoding = NWY_SMS_MSG_FORMAT_TEXT_ASCII;
    char phone_num[] = "18991272537";
    char text[] = "123456789012345@67890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890";
    int result = 0;
    uint32_t text_len = sizeof(text)/sizeof(text[0]);
    nwy_sms_info_type_t  sms_data;
    memcpy (sms_data.phone_num, phone_num, 20);
    sms_data.msg_context_len = text_len;
    memcpy(sms_data.msg_context, text, text_len);
    sms_data.msg_format = encoding;

    nwy_sms_send_message(&sms_data);
}

void test_qmi_send_ucs2()
{
    uint8_t encoding = NWY_SMS_MSG_FORMAT_TEXT_UTF8;
    char phone_num[] = "18991272537";
    nwy_sms_info_type_t  sms_data;
    char text[] = {
        0,0x31,0,0x32,0,0x33,0,0x34,0,0x35,0,0x36,0,0x37,0,0x38,0,0x39, 0, 0x30,
        0,0x31,0,0x32,0,0x33,0,0x34,0,0x35,0,0x36,0,0x37,0,0x38,0,0x39, 0, 0x30,
        0,0x31,0,0x32,0,0x33,0,0x34,0,0x35,0,0x36,0,0x37,0,0x38,0,0x39, 0, 0x30,
        0,0x31,0,0x32,0,0x33,0,0x34,0,0x35,0,0x36,0,0x37,0,0x38,0,0x39, 0, 0x30,
        0,0x31,0,0x32,0,0x33,0,0x34,0,0x35,0,0x36,0,0x37,0,0x38,0,0x39, 0, 0x30,
        0,0x31,0,0x32,0,0x33,0,0x34,0,0x35,0,0x36,0,0x37,0,0x38,0,0x39, 0, 0x30,
        0,0x31,0,0x32,0,0x33,0,0x34,0,0x35,0,0x36,0,0x37,0,0x38,0,0x39, 0, 0x30,
        0,0x31,0,0x32,0,0x33,0,0x34,0,0x35,0,0x36,0,0x37,0,0x38,0,0x39, 0, 0x30,
    };


    int result = 0;
    uint32_t text_len = sizeof(text)/sizeof(text[0]);

    memcpy (sms_data.phone_num, phone_num, 20);
    sms_data.msg_context_len = text_len;
    memcpy(sms_data.msg_context, text, text_len);
    sms_data.msg_format = encoding;

    nwy_sms_send_message(&sms_data);
}

void sms_test_send_async(char *phone, char *text)
{

    int result = 0;
    int i = 0;
    nwy_sms_info_type_t sms_data = { 0 };
    char *input;

    strcpy(sms_data.phone_num, phone);
    sms_data.msg_context_len = strlen(text);
    strcpy(sms_data.msg_context, text);
    sms_data.msg_format = NWY_SMS_MSG_FORMAT_TEXT_ASCII;

        char *h = input_fgets("please set the max waiting time (by second)\n");
        int r = atoi(h);

        if (is_all_dig(h) != 1) {
            PRINTF("input incorrect\n");
            return;
        }


    result = nwy_sms_send_message_async(&sms_data, r);
    if (result == 0) {
        PRINTF("send message to network\n");
    } else {
        PRINTF("send message failed\n");
    }
}

int main(int argc, char *argv[])
{
    int result = 0;

    nwy_sms_add_mtmessage_handler(test_sms_evt_handler, NULL);

   do {
        char *c = NULL;
        c = input_fgets(help_str);

        PRINTF("your input is \"%s\"\n", c);

        PRINTF("======================================\n");
        fflush(stdout);

        if (c[0] > '9' || c[0] < '0') {
            continue;
        }

        int p = atoi(c);

        switch (p) {
            case 1:
                result = test_send_sms(0);
                if (result != 0)
                    PRINTF("Send sms failed\n");
                else
                    PRINTF("Send sms ok\n");
                continue;
            case 2:
                result = test_delete_sms();
                if (result != 0)
                    PRINTF("Del sms failed\n");
                else
                    PRINTF("Del sms ok\n");
                continue;
            case 3:
                result = test_set_sms_route();
                if (result != 0)
                    PRINTF("set route failed\n");
                else
                    PRINTF("set route ok\n");
                continue;
            case 4:
                {
                    nwy_sms_sca_t sca = {0};
                    result = nwy_sms_get_sca(&sca);

                    if (result != 0)
                        PRINTF("get sca failed\n");
                    else
                        PRINTF("sca is %s\n", sca.sca);
                }
                continue;

            case 5:
                {
                    nwy_sms_sca_t sca = {0};
                    c = input_fgets("please input the sca address, include \'+\' if exist\n> ");
                    strncpy(sca.sca, c, NWY_SMS_MAX_ADDR_LENGTH);
                    if (is_phone_number(sca.sca) != 1) {
                        PRINTF("%s is not a phone number\n", sca.sca);
                        continue;
                    }
                    result = nwy_sms_set_sca(&sca);

                    if (result != 0)
                        PRINTF("set sca failed\n");
                    else
                        PRINTF("set sca ok\n");
                }

                continue;

            case 6:
                {
                    nwy_sms_indices_t list = {0};
                    int memstore = 0;
                    char *p = input_fgets("please select the memstore s for sim, n for nv\n>");
                    switch (p[0])
                    {
                        case 's':
                            memstore = NWY_SMS_STORAGE_TYPE_UIM_V01;
                            break;
                        case 'n':
                            memstore = NWY_SMS_STORAGE_TYPE_NV_V01;
                            break;

                        default:
                            continue;
                    }
                    nwy_sms_get_indices(memstore, &list);
                    int i = 0;
                    PRINTF("you have %d message index is :\n", list.len);
                    PRINTF("====================================\n");
                    for (i = 0; i < list.len; i ++){
                        PRINTF("%d,\t", list.indices[i]);
                    }
                    PRINTF("\n====================================\n");
                }
                continue;

            case 7:
                {
                    int memstore = 0;
                    int index = 0;
                    nwy_sms_pp_info_type_t sms_pp = {0};
                    char *p;
                    p = input_fgets("please input the memstore s for sim n for nv\n>");
                    switch (p[0])
                    {
                        case 's':
                            memstore = NWY_SMS_STORAGE_TYPE_UIM_V01;
                            break;
                        case 'n':
                            memstore = NWY_SMS_STORAGE_TYPE_NV_V01;
                            break;

                        default:
                            continue;
                    }
                    p = input_fgets ("please input the index \n> ");
                    index = atoi(p);
                    if (is_all_dig(p) != 1) {
                        PRINTF("input incorrect\n");
                        continue;
                    }


                    int result = nwy_sms_read_msg(memstore, index, &sms_pp); 
                    if (result == 0)
                    {
                        if (sms_pp.is_empty) {
                            PRINTF("no message in index\n");
                            continue;
                        }
                        PRINTF("msg number %s\n", sms_pp.source_phone_num);
                        PRINTF("msg type %d\n", sms_pp.msg_format);
                        if (sms_pp.concat_sms_total > 0) {
                            PRINTF("this is the part %d of long message has %d message entry\n", 
                                    sms_pp.concat_sms_cur, sms_pp.concat_sms_total);
                            PRINTF("concat msg id %d\n", sms_pp.concat_sms_id);
                        }
                        if (sms_pp.msg_format == NWY_SMS_MSG_FORMAT_TEXT_ASCII)
                            PRINTF("recv msg text %s\n", sms_pp.msg_content);
                        else {
                            int i = 0;
                            PRINTF("recv msg data:\n", sms_pp.msg_content);
                            for (i = 0; i < sms_pp.msg_content_len; i++) {
                                PRINTF("%02x", sms_pp.msg_content[i]);
                            }
                            PRINTF("\n");;
                            if (sms_pp.context_decode_type == NWY_SMS_ENCODING_GBK) {

                                PRINTF("gbk data is :\n%s\n", sms_pp.msg_decoded_content);
                            }
                        }
                    }
                    else {
                        PRINTF("msg decode failed\n");
                    }
                }
                continue;

            case 8:
                result = test_send_sms(1);
                if (result != 0)
                    PRINTF("Send sms to network failed\n");
                else
                    PRINTF("Send sms to network\n");
 
                continue;
            case 9:
                result = test_send_sms(2);
                continue;

            case 0:
                break;
            default:
                continue;
        }
        break;
    } while (1);

    return EXIT_SUCCESS;
}


